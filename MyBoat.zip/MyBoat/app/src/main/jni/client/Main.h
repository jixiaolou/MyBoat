#ifndef NDK_NATIVE_ACTIVITY_H
#define NDK_NATIVE_ACTIVITY_H

#include <android/native_activity.h>
#include <pthread.h>
#include "boat.h"
#include "Client.h"


#endif
